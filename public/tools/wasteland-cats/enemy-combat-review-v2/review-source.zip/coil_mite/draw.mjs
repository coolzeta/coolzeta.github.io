import fs from 'node:fs';
import {create} from '/Users/zeta/.codex/skills/pixel-animation/scripts/engine.mjs';
import {writeFrame} from '/Users/zeta/.codex/skills/pixel-animation/scripts/compose.mjs';
import {exportFiles} from '/Users/zeta/.codex/skills/pixel-animation/scripts/pixel.mjs';
import {fileURLToPath} from 'node:url';
const out=fileURLToPath(new URL('.',import.meta.url)), W=320,H=320,p=Array(W*H).fill(null);
const C={ink:'#241f1a',deep:'#3d3025',rust:'#694b32',brown:'#92704b',gold:'#bd925d',light:'#e3c79b',bone:'#eedcba',steel:'#77796b',sl:'#b2b39a',skin:'#987961',skinl:'#c1a181',red:'#784b3c',teal:'#306765',cyan:'#59a6a1',aqua:'#94d9c6',glow:'#d0f4dc'};
function px(x,y,c){x=Math.round(x);y=Math.round(y);if(x>=0&&y>=0&&x<W&&y<H)p[y*W+x]=C[c]||c;}
function poly(v,c){for(let y=Math.max(0,Math.floor(Math.min(...v.map(a=>a[1]))));y<=Math.min(H-1,Math.ceil(Math.max(...v.map(a=>a[1]))));y++){let a=[];for(let i=0,j=v.length-1;i<v.length;j=i++){let u=v[i],b=v[j];if((u[1]>y)!=(b[1]>y))a.push(u[0]+(y-u[1])*(b[0]-u[0])/(b[1]-u[1]));}a.sort((a,b)=>a-b);for(let i=0;i<a.length;i+=2)for(let x=Math.ceil(a[i]);x<=Math.floor(a[i+1]);x++)px(x,y,c);}}
function line(x,y,X,Y,c,w=1){let n=Math.max(Math.abs(X-x),Math.abs(Y-y));for(let i=0;i<=n;i++)for(let a=-Math.floor(w/2);a<=Math.floor(w/2);a++)for(let b=-Math.floor(w/2);b<=Math.floor(w/2);b++)px(x+(X-x)*i/n+a,y+(Y-y)*i/n+b,c);}
function ellipse(x,y,rx,ry,c){for(let j=-ry;j<=ry;j++)for(let i=-rx;i<=rx;i++)if(i*i/rx/rx+j*j/ry/ry<=1)px(x+i,y+j,c);}
function bolt(x,y,r=4){ellipse(x,y,r+1,r+1,'ink');ellipse(x,y,r,r,'brown');ellipse(x-1,y-1,r-1,r-1,'gold');line(x,y-2,x,y+2,'deep');px(x-2,y-2,'bone');}
function tube(a,b,w){line(...a,...b,'ink',w+4);line(...a,...b,'rust',w);line(a[0]-2,a[1]-2,b[0]-2,b[1]-2,'brown',Math.max(1,w-4));line(a[0]-3,a[1]-3,b[0]-3,b[1]-3,'light',1);}
function spring(a,b,n=6){tube(a,b,6);let dx=b[0]-a[0],dy=b[1]-a[1],len=Math.hypot(dx,dy),nx=-dy/len,ny=dx/len;for(let k=0;k<n;k++){let t=(k+.3)/n,x=a[0]+dx*t,y=a[1]+dy*t;line(x-nx*7,y-ny*7,x+nx*7+dx/n*.4,y+ny*7+dy/n*.4,'ink',5);line(x-nx*7,y-ny*7,x+nx*7+dx/n*.4,y+ny*7+dy/n*.4,'brown',3);line(x-nx*7,y-ny*7-1,x+nx*3,y+ny*3-1,'light',1);}}
// far appendages, shorter and occluded
for(const [a,b,c] of [[[217,107],[262,145],[278,211]],[[192,140],[212,184],[208,224]],[[153,169],[152,211],[123,242]]]){tube(a,b,9);spring(b,c,5);poly([[c[0]-4,c[1]-3],[c[0]+4,c[1]],[c[0]+1,c[1]+20],[c[0]-5,c[1]+29]],'deep');}
// copper hose curling behind back cap
line(224,57,230,32,'deep',7);line(230,32,243,26,'brown',5);line(243,26,255,30,'gold',4);line(255,30,261,43,'brown',5);line(261,43,254,64,'deep',7);
// elongated flesh chassis, facing lower left
poly([[135,119],[201,70],[241,78],[258,104],[249,141],[197,188],[159,206],[124,178],[119,145]],'deep');
poly([[145,124],[210,80],[237,87],[246,110],[236,143],[189,185],[159,194],[135,176],[129,148]],'skin');
for(let k=0;k<9;k++){let x=146+k*10,y=139-k*6;poly([[x,y],[x+10,y-3],[x+16,y+20],[x+11,y+35],[x+3,y+39],[x+8,y+19]],k%2?'skinl':'brown');line(x+8,y+4,x+12,y+18,'light',2);line(x+7,y+31,x+1,y+40,'red',2);}
// coil barrel in diagonal perspective
poly([[143,111],[209,62],[233,68],[244,89],[233,112],[168,159],[145,147],[135,126]],'ink');
poly([[148,109],[208,68],[225,72],[234,88],[226,105],[166,149],[147,139],[141,124]],'teal');
poly([[150,111],[210,72],[221,75],[213,86],[154,128],[145,124]],'cyan');
for(let k=0;k<10;k++){let x=149+k*7,y=113-k*4.9;poly([[x,y],[x+5,y-3],[x+14,y+5],[x+18,y+17],[x+14,y+23],[x+9,y+27],[x+11,y+18],[x+7,y+7]],'steel');line(x+1,y,x+9,y+5,'aqua',2);line(x+10,y+7,x+13,y+15,'glow',2);line(x+13,y+17,x+10,y+24,'cyan',2);}
// cap rings, intentionally differing near/far scale
for(const [x,y] of [[211,65],[138,115]]){poly([[x-5,y+2],[x+9,y-6],[x+26,y+3],[x+35,y+20],[x+34,y+36],[x+26,y+47],[x+18,y+44],[x+24,y+31],[x+21,y+15],[x+8,y+5],[x-1,y+10]],'rust');line(x+1,y+2,x+10,y-2,'gold',3);line(x+12,y-1,x+23,y+6,'light',2);line(x+25,y+9,x+30,y+22,'gold',3);for(let j=0;j<4;j++)bolt(x+26+j%2*3,y+13+j*8,2);}
tube([170,157],[234,110],5);bolt(174,155,6);
// neck folds and mechanical skull
poly([[132,139],[147,153],[143,177],[127,193],[101,197],[86,182],[96,157]],'rust');
for(let k=0;k<4;k++){line(113+k*6,149+k*3,101+k*7,174+k*3,'skinl',6);line(108+k*7,164+k*3,107+k*7,183+k*2,'brown',2);}
poly([[111,159],[128,170],[128,188],[112,207],[91,218],[73,217],[66,204],[74,184],[92,169]],'ink');
poly([[109,162],[121,172],[116,181],[96,186],[80,202],[70,202],[77,187],[94,171]],'bone');
poly([[118,178],[126,182],[119,198],[112,209],[99,213],[102,202],[115,195]],'gold');
poly([[96,188],[109,185],[113,190],[107,201],[98,205],[86,204],[83,200]],'brown');ellipse(99,194,8,8,'ink');ellipse(98,192,5,5,'deep');line(94,189,97,187,'sl',2);
poly([[76,202],[89,207],[93,218],[86,222],[82,213],[76,215],[74,226],[69,230],[70,212]],'bone');
for(let k=0;k<5;k++)line(90+k*4,215-k*2,87+k*4,222-k*2,'gold',2);
bolt(122,174,5);bolt(117,205,3);
// fore probe remains connected; short melee jab only
spring([74,207],[61,221],3);tube([61,221],[49,234],6);poly([[47,231],[52,235],[26,263]],'steel');line(47,234,26,263,'bone',1);
// near legs overlap chassis with skin sockets
for(const [a,b,c,d] of [[[155,175],[178,198],[147,244],[130,284]],[[206,143],[218,183],[243,224],[238,278]],[[247,106],[268,124],[292,188],[296,244]]]){ellipse(...a,12,15,'brown');ellipse(a[0]-2,a[1]-3,9,11,'skinl');ellipse(...a,6,9,'deep');tube(a,b,12);bolt(...b,6);spring(b,c,6);bolt(...c,6);tube(c,[d[0],d[1]-20],6);poly([[d[0]-5,d[1]-22],[d[0]+4,d[1]-22],[d[0]+1,d[1]-6],[d[0]-5,d[1]+7]],'steel');line(d[0]-3,d[1]-19,d[0]-5,d[1]+6,'light',1);}
// authored metal chips and chassis scars, not reference-derived
for(const [x,y] of [[220,72],[229,79],[237,98],[168,145],[151,120],[179,166],[196,153],[225,128],[132,156],[116,165]]){line(x,y,x+3,y-1,'light');px(x+1,y+3,'rust');}
// Review revision: carve tapered socket folds and add selective midtone coil reflections.
for(const [x,y] of [[147,167],[198,135],[238,99]]){line(x-4,y-6,x,y-10,'light',2);line(x-5,y+3,x-2,y+10,'red',2);}
for(let k=0;k<6;k++){let x=161+k*8,y=116-k*6;line(x,y,x+3,y+2,'aqua');}
// Material revision: clustered tendon grain, selective bronze nicks and reflected coil light.
for(let y=75;y<197;y++)for(let x=125;x<253;x++){let c=p[y*W+x];if(c===C.skin||c===C.skinl){if((x*5+y*3)%31<2)px(x,y,'brown');else if((x+y*2)%37<2)px(x,y,'light');}}
for(const [x,y,X,Y] of [[171,172,181,164],[182,160,193,153],[209,147,219,139],[145,146,148,157],[221,112,224,119]]){line(x,y,X,Y,'red',2);line(x,y-2,X,Y-2,'skinl');}
const doc=create({name:'coil_mite_static_v2',width:W,height:H,totalFrames:1,fps:8});writeFrame(doc,p);await exportFiles(doc,out+'exports');fs.writeFileSync(out+'manifest.json',JSON.stringify({name:'coil_mite',status:'static_review_only',native_size:[W,H],ground_anchor:{x:178,y:280},facing:'lower_left',attacks:{melee:{type:'short_connected_probe_jab',probe_tip:{x:26,y:263}}},separated_resources:[],connected_parts:['Skull and probe remain attached to neck; probe retracts and jabs, never launches.','Six spring legs articulate from chassis sockets; do not cut into flying pieces.','Back coil cylinder and flesh chassis remain connected.'],reference:'../../minion_individual_references_v1/coil_mite.png',authoring:'Hand-authored coordinates; no reference pixels loaded.'},null,2));
