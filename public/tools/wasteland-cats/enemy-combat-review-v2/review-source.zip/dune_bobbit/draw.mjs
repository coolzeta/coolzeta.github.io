import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {create} from '/Users/zeta/.codex/skills/pixel-animation/scripts/engine.mjs';
import {compose,writeFrame} from '/Users/zeta/.codex/skills/pixel-animation/scripts/compose.mjs';
import {exportFiles} from '/Users/zeta/.codex/skills/pixel-animation/scripts/pixel.mjs';
// Original coordinate drawing. References are visual guidance only; no raster input.
const OUT=path.dirname(fileURLToPath(import.meta.url)), W=320,H=320;
const C={ink:'#2d241f',deep:'#412c25',skin0:'#604336',skin1:'#795442',skin2:'#986d51',skin3:'#b88c64',skin4:'#d4ad7b',skin5:'#ead0a1',scar:'#a26956',scarHi:'#ce9681',metal0:'#343733',metal1:'#53554a',metal2:'#787664',metal3:'#a29c7d',metal4:'#d5c9a2',shine:'#f1e3be',rust0:'#68472f',rust1:'#93613b',rust2:'#bb834b',rust3:'#dca464',mouth:'#261511',flesh0:'#51281f',flesh1:'#76372b',flesh2:'#9e4d39',flesh3:'#c27657',tooth:'#d4b27e',tip:'#f2d6a2'};
function layer(){return {width:W,height:H,pixels:Array(W*H).fill(null)}}
let s;
function dot(x,y,c){x=Math.round(x);y=Math.round(y);if(x>=0&&y>=0&&x<W&&y<H)s.pixels[y*W+x]=C[c]||c;}
function poly(p,c){let min=Math.max(0,Math.floor(Math.min(...p.map(a=>a[1])))),max=Math.min(H-1,Math.ceil(Math.max(...p.map(a=>a[1]))));for(let y=min;y<=max;y++){let xs=[];for(let i=0,j=p.length-1;i<p.length;j=i++){let [xi,yi]=p[i],[xj,yj]=p[j];if((yi>y)!=(yj>y))xs.push(xi+(y-yi)*(xj-xi)/(yj-yi));}xs.sort((a,b)=>a-b);for(let k=0;k<xs.length;k+=2)for(let x=Math.ceil(xs[k]);x<=Math.floor(xs[k+1]);x++)dot(x,y,c);}}
function ell(x,y,rx,ry,c){for(let yy=Math.floor(y-ry);yy<=y+ry;yy++)for(let xx=Math.floor(x-rx);xx<=x+rx;xx++)if(((xx-x)/rx)**2+((yy-y)/ry)**2<=1)dot(xx,yy,c)}
function line(p,c,t=1){for(let i=1;i<p.length;i++){let[a,b]=p[i-1],[x,y]=p[i],n=Math.max(Math.abs(x-a),Math.abs(y-b));for(let k=0;k<=n;k++)for(let u=0;u<t;u++)for(let v=0;v<t;v++)dot(a+(x-a)*k/n+u,b+(y-b)*k/n+v,c);}}
function bolt(x,y,r=3){ell(x,y,r+1,r+1,'ink');ell(x,y,r,r,'metal2');line([[x-r+1,y-1],[x,y-r+1],[x+r-1,y-1]],'metal4');dot(x,y,'metal0');dot(x+1,y+1,'metal1');}
// Segments overlap in depth. Per-segment clusters describe flesh volume; bands stay narrow.
function segment(x,y,rx,ry,variant=0){
 ell(x,y,rx,ry,'skin0');ell(x-2,y-2,rx-2,ry-2,'skin1');
 ell(x-4,y-4,rx-6,ry-5,'skin2');
 poly([[x-rx+5,y-4],[x-rx+10,y-ry+9],[x-9,y-ry+3],[x+10,y-ry+6],[x+rx-10,y-ry+15],[x+rx-11,y-1],[x+6,y+5],[x-14,y+2]],'skin3');
 poly([[x-rx+9,y-7],[x-rx+13,y-ry+11],[x-8,y-ry+6],[x+5,y-ry+8],[x-4,y-ry+11],[x-rx+15,y-6]],'skin4');
 poly([[x-rx+3,y],[x-rx+8,y-ry+8],[x-6,y-ry+2],[x+rx-9,y-ry+9],[x+rx-3,y],[x+rx-8,y+ry-8],[x+5,y+ry-3],[x+rx-3,y+5],[x+rx-6,y-8],[x+2,y-ry+7],[x-rx+12,y-ry+11],[x-rx+8,y+4]],'skin2');
 poly([[x-rx+6,y-3],[x-rx+10,y-ry+9],[x-8,y-ry+4],[x+7,y-ry+6],[x+12,y-ry+13],[x-3,y-ry+10],[x-rx+14,y-7],[x-rx+12,y+4]],'skin3');
 poly([[x-rx+11,y-ry+12],[x-9,y-ry+6],[x+2,y-ry+7],[x-4,y-ry+10],[x-rx+14,y-ry+16]],'skin4');
 line([[x-rx+10,y+1],[x-rx+13,y+7],[x-8,y+ry-7],[x+5,y+ry-5]],'skin0',2);
 line([[x-rx+14,y],[x-rx+17,y+6],[x-6,y+ry-10]],'skin3');
 line([[x+rx-10,y-5],[x+rx-7,y+3],[x+rx-12,y+11]],'scar',2);
 line([[x+rx-13,y-5],[x+rx-11,y+2]],'scarHi');
 // Anatomical crease arcs follow the bulging cross-section.
 line([[x+rx-15,y-ry+14],[x+rx-9,y-3],[x+rx-11,y+7],[x+rx-18,y+ry-6]],'skin0');
 line([[x+rx-18,y-ry+15],[x+rx-12,y-3],[x+rx-15,y+7]],'skin4');
 line([[x-7,y-ry+13],[x+3,y-ry+12],[x+13,y-ry+15],[x+17,y-5]],'skin2');
 line([[x-8,y-ry+11],[x+2,y-ry+10],[x+11,y-ry+12]],'skin4');
 poly([[x-rx+12,y-1],[x-15,y+2],[x-8,y+6],[x-3,y+7],[x-8,y+9],[x-17,y+6]],'skin4');
 for(let [dx,dy] of [[-9,-8],[-15,-3],[4,-12],[7,7],[-4,4]]){dot(x+dx,y+dy,'skin3');dot(x+dx+1,y+dy,'skin3');}
 if(variant){line([[x-rx+1,y+2],[x-rx+6,y+11],[x-9,y+ry-1],[x+8,y+ry],[x+rx-5,y+ry-9],[x+rx,y+2]],'metal0',5);line([[x-rx+2,y+2],[x-rx+8,y+10],[x-9,y+ry-3],[x+8,y+ry-2],[x+rx-7,y+ry-11]],'metal2',3);line([[x-rx+2,y+2],[x-rx+8,y+9],[x-9,y+ry-4]],'metal4');poly([[x+10,y+ry-8],[x+21,y+ry-13],[x+23,y+ry-7],[x+12,y+ry-2]],'rust1');bolt(x+15,y+ry-7,2);}
}
const body=layer();s=body;
// Far antennae and bristles: paired anatomy in a three-quarter view.
line([[151,57],[140,34],[121,22],[99,15],[80,16],[72,25]],'deep',3);
line([[151,57],[139,33],[120,21],[98,14],[80,15],[73,22]],'rust2');
line([[174,63],[179,40],[179,23],[172,12],[166,12],[163,17]],'deep',3);
line([[175,60],[180,39],[179,23],[172,11],[166,11],[163,16]],'skin4');
for(let p of [[[254,271],[267,266],[274,269]],[[270,247],[281,244],[284,250]],[[278,222],[286,217],[290,222]],[[275,198],[283,191],[287,193]],[[258,171],[267,162],[274,164]],[[233,145],[241,135],[249,138]]]){line(p,'deep',2);line(p,'skin3');}
// Tail folded behind the foreground base.
segment(106,279,36,21,1);segment(120,260,38,25,1);segment(143,240,34,25,1);segment(167,226,34,27,1);
// Raised neck rises from a weight-bearing curl, back to front.
segment(199,279,54,25,1);segment(223,259,52,31,1);segment(239,235,43,33,1);segment(242,210,37,33,1);segment(232,187,39,31,1);segment(217,164,40,29,1);segment(200,143,39,28,1);segment(184,123,36,26,1);
// Foreground fleshy foot of curl, with explicit wrinkles and chest-like segmented scale.
segment(176,290,43,17,0);
line([[140,290],[146,279],[156,275],[171,275],[186,280],[192,289]],'skin0',2);
line([[149,292],[154,285],[164,282],[177,284],[182,291]],'skin2',2);
line([[156,298],[161,290],[169,289],[175,295]],'skin0');
// Neck outer iron collar follows the right-hand contour.
poly([[153,61],[180,62],[203,85],[213,115],[205,144],[187,159],[166,153],[183,137],[190,113],[184,87]],'metal0');
poly([[165,63],[181,69],[198,87],[207,113],[199,139],[186,151],[178,150],[192,133],[198,114],[190,89]],'rust1');
poly([[161,62],[175,65],[194,83],[196,91],[188,86],[175,73],[163,70]],'metal4');
poly([[200,103],[206,114],[200,137],[188,148],[184,147],[195,133]],'metal2');
line([[182,74],[198,96],[201,111],[195,132],[183,144]],'rust3');
for(let [x,y] of [[180,72],[197,93],[202,116],[194,137],[182,149]])bolt(x,y,3);
// Full mouth and continuous back tissue exist even when the launch jaw is absent.
ell(132,102,58,61,'deep');ell(132,101,54,57,'flesh0');ell(127,102,46,51,'mouth');
poly([[107,59],[122,48],[141,51],[158,62],[169,81],[168,101],[157,89],[153,71],[138,62],[124,59]],'flesh1');
poly([[85,100],[93,119],[104,139],[125,148],[145,137],[159,119],[162,110],[156,112],[144,129],[126,136],[109,132],[99,117]],'flesh1');
poly([[118,113],[130,103],[143,109],[144,118],[136,123],[128,121],[129,116],[136,115],[131,112],[124,118],[126,128],[138,130],[144,136],[130,141],[118,132],[113,123]],'flesh2');
line([[121,120],[125,126],[132,126],[139,130]],'flesh3',2);
line([[126,67],[132,77],[130,86],[137,93]],'flesh1',3);
line([[149,87],[141,90],[140,100]],'flesh2',2);
// Ragged but ordered inward teeth, separate upper/lower depth planes.
for(let p of [[[99,65],[109,71],[107,61]],[[112,57],[120,68],[120,55]],[[130,55],[134,65],[138,57]],[[147,60],[145,70],[153,66]],[[159,74],[150,80],[163,81]],[[88,85],[100,88],[91,78]],[[84,99],[95,100],[86,92]],[[91,116],[101,112],[93,122]],[[100,132],[108,119],[110,137]],[[113,141],[118,127],[122,144]],[[130,143],[134,130],[138,139]],[[146,132],[146,120],[153,125]],[[157,116],[151,111],[162,108]]]){poly(p,'tooth');line([p[0],p[1]],'tip');}
// Head crown and jaw collar, selective lit edges rather than nested black rings.
poly([[79,66],[88,49],[112,38],[139,38],[160,48],[174,66],[183,88],[183,112],[174,132],[155,151],[130,158],[108,151],[116,144],[134,148],[153,140],[166,124],[174,103],[174,83],[163,62],[146,48],[119,45],[98,55],[89,70]],'metal1');
poly([[80,63],[89,49],[112,39],[137,39],[151,44],[157,51],[140,46],[116,45],[98,53],[87,68]],'metal3');
line([[86,56],[97,47],[115,41],[138,41],[150,46]],'shine');
poly([[172,77],[182,89],[181,111],[172,133],[155,150],[132,155],[116,150],[134,149],[153,141],[166,125],[174,104]],'metal2');
line([[179,108],[170,129],[153,147],[134,152]],'metal4');
poly([[160,51],[168,60],[173,73],[168,70],[158,57]],'rust1');
poly([[157,138],[167,128],[173,124],[168,138],[155,149],[147,150]],'rust1');
for(let [x,y] of [[105,45],[143,44],[170,68],[178,100],[163,139],[136,153]])bolt(x,y,2);
// Open, load-bearing launch socket. This is body tissue/hardware, never duplicate jaw pixels.
ell(167,100,21,25,'metal0');ell(166,99,18,22,'metal2');ell(164,98,14,18,'rust0');ell(164,98,10,13,'metal0');ell(164,98,5,7,'deep');
line([[152,89],[157,81],[165,80],[172,85]],'metal4',2);line([[179,97],[178,108],[170,118]],'rust2',2);bolt(180,91,2);bolt(174,117,2);
// Rigid drill construction in local axial coordinates. Hand-authored rings form tapered metal.
function drill(cx,cy,len,wide,angle){
 const cs=Math.cos(angle),sn=Math.sin(angle);const tr=(u,v)=>[Math.round(cx+u*cs-v*sn),Math.round(cy+u*sn+v*cs)];
 const P=(p,c)=>poly(p.map(([u,v])=>tr(u,v)),c);const L=(p,c,t=1)=>line(p.map(([u,v])=>tr(u,v)),c,t);
 P([[5,-wide*.78],[0,-wide],[-9,-wide*.96],[-len,-2],[-len-5,0],[-len,3],[-10,wide],[0,wide],[7,wide*.65]],'metal0');
 P([[0,-wide*.92],[-10,-wide*.88],[-len-4,0],[-9,wide*.87],[0,wide*.84],[5,wide*.55],[5,-wide*.5]],'rust1');
 P([[-6,-wide*.84],[-17,-wide*.68],[-len-3,0],[-18,wide*.22],[-6,wide*.28],[2,0]],'metal3');
 P([[-6,wide*.27],[-17,wide*.23],[-len-2,1],[-12,wide*.8],[0,wide*.79],[5,wide*.52]],'rust0');
 P([[-5,-wide*.82],[-12,-wide*.73],[-len-1,-1],[-17,-wide*.17],[-6,-wide*.23]],'metal4');
 for(let [u,f] of [[-5,.9],[-14,.73],[-23,.56],[-32,.4],[-41,.23]]){if(-u>len-3)continue;let r=wide*f;L([[u+2,-r],[u-1,-r+3],[u+1,-r*.25],[u+3,r*.32],[u+1,r*.75],[u-2,r]],'metal0',2);L([[u,-r],[u-3,-r+3],[u-1,-r*.25],[u+1,r*.32]],'shine');L([[u+4,r*.34],[u+2,r*.76]],'rust2');}
 L([[-len-4,0],[-len+4,-2]],'shine');
 P([[2,-wide*.75],[6,-wide*.52],[7,wide*.48],[2,wide*.76],[0,wide*.49],[3,-wide*.45]],'metal2');
 for(let v of [-.57,.55]){let [x,y]=tr(3,wide*v);bolt(x,y,2);}
}
// Two permanent far drills, attached to head.
drill(101,71,48,22,0.12);
drill(118,139,48,21,-0.65);
// Sensory feelers along the mouth rim; these remain on the body.
line([[87,103],[65,108],[50,122],[45,142]],'deep',2);line([[87,103],[65,108],[50,121],[45,140]],'rust2');
line([[156,145],[139,166],[132,184],[132,198],[136,207]],'deep',2);line([[156,145],[139,165],[132,184],[132,198]],'skin3');
const jaw=layer();s=jaw;
drill(167,100,51,23,0.06);
// Visible keyed heel only belongs to the launched rigid projectile.
poly([[169,91],[174,92],[176,99],[174,107],[169,109],[170,104],[171,98]],'metal1');
line([[171,92],[174,94],[175,98]],'metal4');
const assembled=compose(W,H,[{sprite:body},{sprite:jaw}]);
for(let [name,pixels] of [['body',body.pixels],['detachable_jaw',jaw.pixels],['assembled',assembled]]){const doc=create({name:'dune-bobbit-'+name,width:W,height:H,totalFrames:1,fps:1});writeFrame(doc,pixels);await exportFiles(doc,path.join(OUT,name));if(name==='assembled')await exportFiles(doc,path.join(OUT,'exports'));}
fs.writeFileSync(path.join(OUT,'manifest.json'),JSON.stringify({name:'dune_bobbit',stage:'static design review; no animation or game integration',native_pixels:[320,320],reference:'../../minion_individual_references_v1/dune_bobbit.png',authorship:'Original handwritten geometry; no reference pixel sampling, tracing or transformation.',body:'body/frame-001.png',detachable_jaw:'detachable_jaw/frame-001.png',assembled:'assembled/frame-001.png',draw_order:['body','detachable_jaw'],coordinates:{origin:'top-left',jaw_attach:[167,100],jaw_pivot:[167,100],muzzle:[167,100],jaw_tip:[111,97],ground_anchor:[187,306]},part_contract:{body:'Contains uninterrupted mouth flesh, shaft socket and two permanently attached drill jaws. Does not contain detachable jaw.',detachable_jaw:'One complete rigid near-side drill, transparent full-size canvas, keyed heel included.',attack:'Low-count elite ranged attacker; launches only this near-side jaw at high damage, then recalls it. No scaling or stretching. Path and release/recovery poses deferred to animation approval.'}},null,2));
console.log('Exported body, detachable jaw, assembled and canonical exports at 320x320.');
// Integer nearest-neighbour review image, derived only from the authored pixels.
const {PNG}=await import('/Users/zeta/.codex/skills/pixel-animation/node_modules/pngjs/lib/png.js');
for(const [name,pixels] of [['body',body.pixels],['detachable_jaw',jaw.pixels],['assembled',assembled]]){
 const z=4, out=new PNG({width:W*z,height:H*z});
 for(let y=0;y<H*z;y++)for(let x=0;x<W*z;x++){const c=pixels[Math.floor(y/z)*W+Math.floor(x/z)];if(c){const i=(y*W*z+x)*4;out.data[i]=parseInt(c.slice(1,3),16);out.data[i+1]=parseInt(c.slice(3,5),16);out.data[i+2]=parseInt(c.slice(5,7),16);out.data[i+3]=255;}}
 fs.writeFileSync(path.join(OUT,name,'frame-001-4x.png'),PNG.sync.write(out));
 if(name==='assembled')fs.writeFileSync(path.join(OUT,'exports','frame-001-4x.png'),PNG.sync.write(out));
}
let bb={minX:W,minY:H,maxX:0,maxY:0},count=0;
for(let i=0;i<jaw.pixels.length;i++)if(jaw.pixels[i]){const x=i%W,y=Math.floor(i/W);bb.minX=Math.min(bb.minX,x);bb.maxX=Math.max(bb.maxX,x);bb.minY=Math.min(bb.minY,y);bb.maxY=Math.max(bb.maxY,y);count++;}
const exactComposite=assembled.every((p,i)=>p===(jaw.pixels[i]||body.pixels[i]));
if(!exactComposite)throw Error('Part composition mismatch');
fs.writeFileSync(path.join(OUT,'static-review.json'),JSON.stringify({native:[W,H],jawOpaquePixels:count,jawBounds:bb,exactComposite,visualReview:'All three static PNGs reviewed. Revised broad flesh volumes and contour-following folds after first inspection. No animation made or tested.'},null,2));
