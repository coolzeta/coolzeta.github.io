import fs from 'node:fs';
import {create} from '/Users/zeta/.codex/skills/pixel-animation/scripts/engine.mjs';
import {writeFrame} from '/Users/zeta/.codex/skills/pixel-animation/scripts/compose.mjs';
import {exportFiles} from '/Users/zeta/.codex/skills/pixel-animation/scripts/pixel.mjs';
import {fileURLToPath} from 'node:url';
const out=fileURLToPath(new URL('.',import.meta.url)), W=48,H=48,p=Array(W*H).fill(null);
const C={ink:'#241f1a',deep:'#3d3025',rust:'#694b32',brown:'#92704b',gold:'#bd925d',light:'#e3c79b',bone:'#eedcba',steel:'#77796b',sl:'#b2b39a',skin:'#987961',skinl:'#c1a181',red:'#784b3c',teal:'#306765',cyan:'#59a6a1',aqua:'#94d9c6',glow:'#d0f4dc'};
function px(x,y,c){x=Math.round(x);y=Math.round(y);if(x>=0&&y>=0&&x<W&&y<H)p[y*W+x]=C[c]||c;}
function poly(v,c){for(let y=Math.max(0,Math.floor(Math.min(...v.map(a=>a[1]))));y<=Math.min(H-1,Math.ceil(Math.max(...v.map(a=>a[1]))));y++){let a=[];for(let i=0,j=v.length-1;i<v.length;j=i++){let u=v[i],b=v[j];if((u[1]>y)!=(b[1]>y))a.push(u[0]+(y-u[1])*(b[0]-u[0])/(b[1]-u[1]));}a.sort((a,b)=>a-b);for(let i=0;i<a.length;i+=2)for(let x=Math.ceil(a[i]);x<=Math.floor(a[i+1]);x++)px(x,y,c);}}
function line(x,y,X,Y,c,w=1){let n=Math.max(Math.abs(X-x),Math.abs(Y-y));for(let i=0;i<=n;i++)for(let a=-Math.floor(w/2);a<=Math.floor(w/2);a++)for(let b=-Math.floor(w/2);b<=Math.floor(w/2);b++)px(x+(X-x)*i/n+a,y+(Y-y)*i/n+b,c);}
function ellipse(x,y,rx,ry,c){for(let j=-ry;j<=ry;j++)for(let i=-rx;i<=rx;i++)if(i*i/rx/rx+j*j/ry/ry<=1)px(x+i,y+j,c);}
function bolt(x,y,r=4){ellipse(x,y,r+1,r+1,'ink');ellipse(x,y,r,r,'brown');ellipse(x-1,y-1,r-1,r-1,'gold');line(x,y-2,x,y+2,'deep');px(x-2,y-2,'bone');}
function tube(a,b,w){line(...a,...b,'ink',w+4);line(...a,...b,'rust',w);line(a[0]-2,a[1]-2,b[0]-2,b[1]-2,'brown',Math.max(1,w-4));line(a[0]-3,a[1]-3,b[0]-3,b[1]-3,'light',1);}
function spring(a,b,n=6){tube(a,b,6);let dx=b[0]-a[0],dy=b[1]-a[1],len=Math.hypot(dx,dy),nx=-dy/len,ny=dx/len;for(let k=0;k<n;k++){let t=(k+.3)/n,x=a[0]+dx*t,y=a[1]+dy*t;line(x-nx*7,y-ny*7,x+nx*7+dx/n*.4,y+ny*7+dy/n*.4,'ink',5);line(x-nx*7,y-ny*7,x+nx*7+dx/n*.4,y+ny*7+dy/n*.4,'brown',3);line(x-nx*7,y-ny*7-1,x+nx*3,y+ny*3-1,'light',1);}}
// Free ember pellet, facing lower left. Not a removed chest organ.
poly([[11,27],[17,17],[25,18],[36,9],[32,23],[39,20],[32,32],[27,37],[17,38],[10,33]],'#823421');
poly([[12,28],[18,21],[25,22],[32,16],[29,27],[34,26],[28,33],[19,36],[13,32]],'#df5728');
poly([[15,28],[19,24],[24,25],[27,23],[26,30],[22,34],[16,33]],'#ffac3c');
poly([[16,28],[21,26],[23,29],[21,32],[16,31]],'#fff0a4');
line(29,16,32,11,'#ffb54b',1);px(35,14,'#b64b26');px(29,7,'#e8782e');
// Native review revision: darker crust separates the pellet from its short flame.
line(12,30,14,34,'#9f3a23',2);px(17,27,'#fff7c4');px(18,28,'#fff7c4');
const doc=create({name:'ember_pellet_static_v2',width:W,height:H,totalFrames:1,fps:8});writeFrame(doc,p);await exportFiles(doc,out+'exports');
fs.writeFileSync(out+'manifest.json',JSON.stringify({native_size:[48,48],anchor:{x:21,y:28},collision_center:{x:21,y:28},collision_radius:7,source:'ember_bat mouth or chest vent',connected_to_body:false,status:'static_review_only'},null,2));
