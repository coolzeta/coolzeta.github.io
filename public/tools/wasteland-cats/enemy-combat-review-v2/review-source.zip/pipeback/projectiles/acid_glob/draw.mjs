// Hand-authored coordinates only; reference inspected visually, never read as pixels.
import {create} from '/Users/zeta/.codex/skills/pixel-animation/scripts/engine.mjs';
import {writeFrame} from '/Users/zeta/.codex/skills/pixel-animation/scripts/compose.mjs';
import {exportFiles} from '/Users/zeta/.codex/skills/pixel-animation/scripts/pixel.mjs';
const W=64,H=64,px=Array(W*H).fill(null);
const C={edge:'#302c23',deep:'#444438',s0:'#535644',s1:'#71745a',s2:'#969577',s3:'#b6b28a',s4:'#d2c6a0',rust0:'#50382c',rust1:'#765039',rust2:'#a36d43',rust3:'#cb955e',rust4:'#ebbf81',metal0:'#343e39',metal1:'#59655c',metal2:'#879084',metal3:'#bac0a8',light:'#eee0b8',hot0:'#773b27',hot1:'#bd5426',hot2:'#ed8b37',hot3:'#ffd176'};
function p(c,pts){c=C[c]||c;for(let y=Math.max(0,Math.min(...pts.map(v=>v[1])));y<=Math.min(H-1,Math.max(...pts.map(v=>v[1])));y++){let xs=[];for(let i=0,j=pts.length-1;i<pts.length;j=i++){let a=pts[i],b=pts[j];if((a[1]>y+.5)!=(b[1]>y+.5))xs.push(a[0]+(y+.5-a[1])*(b[0]-a[0])/(b[1]-a[1]));}xs.sort((a,b)=>a-b);for(let i=0;i<xs.length;i+=2)for(let x=Math.max(0,Math.ceil(xs[i]-.5));x<Math.min(W,Math.ceil(xs[i+1]-.5));x++)px[y*W+x]=c;}}
function r(c,x,y,w=1,h=1){p(c,[[x,y],[x+w,y],[x+w,y+h],[x,y+h]]);}
function l(c,pts,w=1){for(let k=1;k<pts.length;k++){let a=pts[k-1],b=pts[k],n=Math.max(Math.abs(b[0]-a[0]),Math.abs(b[1]-a[1]));for(let t=0;t<=n;t++)r(c,Math.round(a[0]+(b[0]-a[0])*t/n),Math.round(a[1]+(b[1]-a[1])*t/n),w,w);}}
function e(c,x,y,rx,ry=rx){let pts=[];for(let i=0;i<24;i++){let a=i*Math.PI/12;pts.push([Math.round(x+Math.cos(a)*rx),Math.round(y+Math.sin(a)*ry)]);}p(c,pts);}
function bolt(x,y,s=2){e('rust0',x,y,s+1);e('metal2',x,y,s);r('light',x-1,y-1);r('metal0',x,y,1,2);}
function pipe(pts,w=9){l('rust0',pts,w);l('rust2',pts.map(([x,y])=>[x+1,y+1]),w-3);l('metal2',pts.map(([x,y])=>[x+2,y+1]),2);}
async function finish(name){const doc=create({name,width:W,height:H,totalFrames:1,fps:1});writeFrame(doc,px);const out=decodeURIComponent(new URL('./exports',import.meta.url).pathname);await exportFiles(doc,out);}
// Independent acid projectile; a free droplet only, never a detached throat sac.
p('#344835',[[13,27],[18,19],[29,15],[38,19],[42,25],[42,35],[36,44],[26,47],[17,41],[12,33]]);
p('#718d4d',[[14,27],[20,20],[29,17],[36,20],[40,27],[39,35],[34,42],[26,44],[19,40],[15,34]]);
p('#adbf70',[[16,26],[21,21],[29,19],[33,22],[33,28],[27,35],[20,35],[16,31]]);
p('#e3e4a9',[[20,24],[24,21],[28,22],[26,27],[21,29],[19,27]]);
p('#526d40',[[35,27],[39,30],[37,37],[31,42],[24,42],[31,37]]);
p('#98a95a',[[16,34],[23,38],[30,38],[27,42],[21,40]]);
p('#536945',[[39,25],[47,23],[51,19],[49,26],[43,31]]);
p('#a5b574',[[41,26],[46,25],[44,28]]);
e('#82995c',50,36,3,2);r('#cad692',49,35,1,1);
// Review 2: short taper and one detached satellite make travel direction readable.
p('#6f874a',[[43,25],[47,19],[53,16],[48,23],[45,29]]);
p('#bacb84',[[46,22],[50,18],[48,22]]);
e('#93ad61',55,13,2,2);r('#d3dea3',54,12);
await finish('pipeback-acid-glob-static-v2');
