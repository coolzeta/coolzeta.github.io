import fs from 'node:fs';
import {create} from '/Users/zeta/.codex/skills/pixel-animation/scripts/engine.mjs';
import {writeFrame} from '/Users/zeta/.codex/skills/pixel-animation/scripts/compose.mjs';
import {exportFiles} from '/Users/zeta/.codex/skills/pixel-animation/scripts/pixel.mjs';
import {fileURLToPath} from 'node:url';
const out=fileURLToPath(new URL('.',import.meta.url)), W=320,H=320,p=Array(W*H).fill(null);
const C={ink:'#241f1a',deep:'#3d3025',rust:'#694b32',brown:'#92704b',gold:'#bd925d',light:'#e3c79b',bone:'#eedcba',steel:'#77796b',sl:'#b2b39a',skin:'#987961',skinl:'#c1a181',red:'#784b3c',teal:'#306765',cyan:'#59a6a1',aqua:'#94d9c6',glow:'#d0f4dc'};
function px(x,y,c){x=Math.round(x);y=Math.round(y);if(x>=0&&y>=0&&x<W&&y<H)p[y*W+x]=C[c]||c;}
function poly(v,c){for(let y=Math.max(0,Math.floor(Math.min(...v.map(a=>a[1]))));y<=Math.min(H-1,Math.ceil(Math.max(...v.map(a=>a[1]))));y++){let a=[];for(let i=0,j=v.length-1;i<v.length;j=i++){let u=v[i],b=v[j];if((u[1]>y)!=(b[1]>y))a.push(u[0]+(y-u[1])*(b[0]-u[0])/(b[1]-u[1]));}a.sort((a,b)=>a-b);for(let i=0;i<a.length;i+=2)for(let x=Math.ceil(a[i]);x<=Math.floor(a[i+1]);x++)px(x,y,c);}}
function line(x,y,X,Y,c,w=1){let n=Math.max(Math.abs(X-x),Math.abs(Y-y));for(let i=0;i<=n;i++)for(let a=-Math.floor(w/2);a<=Math.floor(w/2);a++)for(let b=-Math.floor(w/2);b<=Math.floor(w/2);b++)px(x+(X-x)*i/n+a,y+(Y-y)*i/n+b,c);}
function ellipse(x,y,rx,ry,c){for(let j=-ry;j<=ry;j++)for(let i=-rx;i<=rx;i++)if(i*i/rx/rx+j*j/ry/ry<=1)px(x+i,y+j,c);}
function bolt(x,y,r=4){ellipse(x,y,r+1,r+1,'ink');ellipse(x,y,r,r,'brown');ellipse(x-1,y-1,r-1,r-1,'gold');line(x,y-2,x,y+2,'deep');px(x-2,y-2,'bone');}
function tube(a,b,w){line(...a,...b,'ink',w+4);line(...a,...b,'rust',w);line(a[0]-2,a[1]-2,b[0]-2,b[1]-2,'brown',Math.max(1,w-4));line(a[0]-3,a[1]-3,b[0]-3,b[1]-3,'light',1);}
function spring(a,b,n=6){tube(a,b,6);let dx=b[0]-a[0],dy=b[1]-a[1],len=Math.hypot(dx,dy),nx=-dy/len,ny=dx/len;for(let k=0;k<n;k++){let t=(k+.3)/n,x=a[0]+dx*t,y=a[1]+dy*t;line(x-nx*7,y-ny*7,x+nx*7+dx/n*.4,y+ny*7+dy/n*.4,'ink',5);line(x-nx*7,y-ny*7,x+nx*7+dx/n*.4,y+ny*7+dy/n*.4,'brown',3);line(x-nx*7,y-ny*7-1,x+nx*3,y+ny*3-1,'light',1);}}
// Three-quarter forward-left view; far wing smaller and darker.
function wing(root,tip,mid,low,near){let [x,y]=root;poly([root,tip,[tip[0]-7,tip[1]+15],[tip[0]-8,tip[1]+29],[tip[0]-4,tip[1]+43],[mid[0]-15,mid[1]-9],mid,[mid[0]-17,mid[1]+10],[mid[0]-22,mid[1]+24],[mid[0]-18,mid[1]+37],[mid[0]-22,mid[1]+42],[mid[0]-12,mid[1]+48],[low[0]-12,low[1]-23],low,[low[0]-20,low[1]-14],[low[0]-31,low[1]-10],[low[0]-39,low[1]+2],[low[0]-46,low[1]+20],[low[0]-53,low[1]+1],[x+20,y+35]],near?'#803c2c':'#56352d');
const membraneMask=p.map(Boolean);
const shade=near?'#ae4c32':'#754334',lit=near?'#ce6140':'#8d513b';
poly([root,[tip[0]-5,tip[1]+11],[tip[0]-14,tip[1]+30],[x+16,y-5]],shade);poly([root,[mid[0]-13,mid[1]-5],[mid[0]-22,mid[1]+12],[x+18,y+13]],shade);poly([[x+11,y+15],[low[0]-10,low[1]-12],[low[0]-35,low[1]-19],[x+28,y+26]],shade);
for(let k=0;k<8;k++){let t=(k+1)/10;line(x+8,y+6,mid[0]*t+x*(1-t)-5,mid[1]*t+y*(1-t)+12,near?'#9b4934':'#674033',1);}
for(let j=0;j<p.length;j++)if(!membraneMask[j])p[j]=null;
for(const b of [tip,mid,low]){tube(root,b,near?5:4);for(let t=.3;t<.98;t+=.28)bolt(Math.round(x+(b[0]-x)*t),Math.round(y+(b[1]-y)*t),2);}
line(x+8,y+9,low[0]-27,low[1]-17,lit,1);
for(const [hx,hy,rx,ry] of [[tip[0]-7,tip[1]+34,3,5],[mid[0]-12,mid[1]+21,3,7],[low[0]-23,low[1]-16,4,8],[low[0]-38,low[1]-11,3,5]]){ellipse(hx,hy,rx,ry,null);}
bolt(x,y,6);poly([[tip[0]-2,tip[1]-3],[tip[0]+12,tip[1]-4],[tip[0]+21,tip[1]+4],[tip[0]+23,tip[1]+12],[tip[0]+16,tip[1]+3],[tip[0]+3,tip[1]+1]],'brown');}
wing([53,113],[104,35],[120,104],[143,170],false);
tube([61,124],[105,181],8);
// far legs and connected rear tail
poly([[173,193],[209,207],[240,234],[270,246],[265,254],[239,248],[208,224],[170,214]],'deep');
poly([[180,195],[213,214],[240,235],[237,240],[207,222],[174,207]],'skin');
tube([218,224],[247,267],7);bolt(243,260,4);
for(let k=0;k<3;k++)poly([[244+k*6,268],[250+k*6,271],[246+k*8,280],[244+k*7,274]],'brown');
poly([[117,201],[122,225],[99,244],[65,254],[62,249],[93,238],[103,218],[102,200]],'red');tube([97,241],[68,253],5);
// torso underside, sinew and ribbed armor
poly([[110,170],[137,150],[174,157],[205,185],[210,213],[185,237],[156,232],[125,213],[98,202]],'deep');
poly([[127,172],[145,160],[176,170],[194,191],[187,217],[168,224],[145,210],[121,201]],'skin');
for(let k=0;k<6;k++){line(132+k*8,172+k*4,127+k*9,194+k*4,'brown',7);line(131+k*8,170+k*4,126+k*9,187+k*4,'skinl',2);}
wing([182,107],[267,24],[292,94],[302,203],true);tube([181,113],[176,162],8);
// backpack engine and upper spine
for(let k=0;k<6;k++){ellipse(121+k*8,160-k%2*3,9,11,'ink');ellipse(121+k*8,158-k%2*3,7,8,'steel');line(117+k*8,153-k%2*3,120+k*8,151-k%2*3,'sl',2);}
// turbine foreshortened oval housing
ellipse(179,163,24,29,'ink');ellipse(177,161,23,27,'rust');ellipse(174,157,20,24,'sl');ellipse(178,160,18,23,'deep');ellipse(179,160,15,20,'ink');
for(let k=0;k<11;k++){let a=k*Math.PI*2/11;line(179,160,179+Math.cos(a)*14,160+Math.sin(a)*19,'steel',2);line(180,159,180+Math.cos(a)*11,159+Math.sin(a)*15,'brown',1);}ellipse(179,160,5,6,'sl');bolt(179,160,3);line(159,149,161,138,'bone',2);for(let k=0;k<5;k++)bolt(160+k*8,181+Math.round(Math.sin(k)*3),2);
// fixed incandescent chest organ in rib cage
for(const [x,y,r] of [[129,212,13],[148,214,16],[163,223,12]]){ellipse(x,y,r+3,r+5,'deep');ellipse(x,y,r,r+2,'#9e3823');ellipse(x-2,y-3,r-3,r-3,'#df5827');ellipse(x-4,y-5,r-6,r-7,'#ff9f3e');line(x-6,y-8,x-3,y-10,'#ffe89a',2);for(let k=0;k<3;k++)px(x+k*3-5,y+k*2,'#ffd270');}
tube([115,189],[114,214],3);tube([166,201],[178,221],3);
// neck, connected skull jaws and tall asymmetric ears
poly([[111,169],[132,179],[121,195],[92,198],[75,185],[87,168]],'red');for(let k=0;k<5;k++)line(100+k*5,168,91+k*5,188,'brown',5);
poly([[64,177],[56,152],[59,139],[73,163],[83,170]],'deep');poly([[62,171],[61,150],[70,167]],'red');
poly([[92,171],[98,138],[106,124],[105,158],[100,178]],'deep');poly([[97,166],[101,142],[103,136],[102,161]],'#aa5c43');
poly([[89,165],[109,170],[110,189],[99,207],[78,218],[63,208],[51,195],[55,181],[70,172]],'ink');
poly([[84,166],[96,165],[94,173],[74,185],[56,189],[54,183],[69,174]],'sl');poly([[91,171],[105,172],[99,184],[90,194],[77,195],[72,189]],'brown');
poly([[58,190],[68,189],[78,197],[98,193],[91,211],[77,224],[62,216]],'ink');poly([[88,205],[87,213],[75,219],[67,213],[75,214]],'red');
poly([[65,215],[77,222],[94,207],[101,198],[99,211],[79,230],[65,224]],'brown');line(66,222,77,226,'light',2);line(80,225,94,212,'sl',2);
for(let k=0;k<6;k++){let x=59+k*6,y=194+(k<3?k:5-k);poly([[x,y],[x+3,y],[x+2,y+7+(k%2)*2]],'bone');}for(let k=0;k<5;k++){let x=69+k*5,y=222-k*2;poly([[x,y],[x+3,y-1],[x+2,y-6]],'light');}
ellipse(86,184,7,7,'ink');ellipse(86,184,4,4,'#df5323');ellipse(85,183,2,3,'#ffe7a0');bolt(104,190,4);poly([[53,183],[65,180],[66,187],[60,192],[52,188]],'sl');ellipse(56,186,2,2,'deep');line(68,177,78,174,'bone',2);
// near shoulder and long muscular dive claw arm
poly([[172,190],[190,198],[199,215],[188,234],[173,246],[164,268],[145,282],[129,280],[131,271],[151,258],[158,237],[176,215],[165,204]],'deep');
poly([[173,193],[185,201],[190,214],[178,229],[166,237],[159,262],[143,274],[138,273],[154,257],[159,232],[178,213],[168,202]],'skin');
poly([[178,199],[185,208],[182,218],[171,228],[169,224],[180,212]],'skinl');line(165,240,160,258,'red',3);tube([174,232],[155,265],4);bolt(166,247,6);
for(const [x,y,X,Y] of [[136,274,119,296],[146,279,139,303],[155,276,154,296],[132,270,111,280]]){tube([x,y],[X+3,Y-8],4);poly([[X+1,Y-11],[X+5,Y-8],[X,Y+2],[X-1,Y-3]],'bone');}
for(const [x,y] of [[71,253],[64,254],[58,253]]){tube([x,y],[x-6,y+7],4);poly([[x-9,y+6],[x-4,y+8],[x-11,y+19]],'light');}
// authored burn tears: dark scars and clustered membrane flecks
for(const [x,y] of [[238,66],[258,79],[258,115],[271,141],[280,166],[226,129],[211,124],[90,86]]){line(x,y,x+2,y+3,'#502c25',2);px(x+3,y+5,'#c36543');}
// Visual revision after native inspection: membrane fibers and clustered mottling,
// restricted to the authored membrane colors so wing spars retain clean joins.
const membrane=new Set(['#803c2c','#ae4c32','#ce6140','#9b4934','#56352d','#754334','#8d513b','#674033']);
for(let y=20;y<224;y++)for(let x=40;x<310;x++){let c=p[y*W+x];if(!membrane.has(c))continue;let near=x>170,rx=near?182:53,ry=near?107:113;let a=Math.atan2(y-ry,x-rx),r=Math.hypot(x-rx,y-ry);let fold=Math.sin(a*41+Math.sin(r/19)*.7);if(fold>.86&&r>15)px(x,y,near?'#bc573b':'#87503c');else if(fold<-.9&&r>20)px(x,y,near?'#673327':'#4b3029');else if((x*7+y*11)%47<3&&r>28)px(x,y,near?'#97452f':'#684030');}
// Muscle fibers and scorched flesh ridges preserve the continuous arm volume.
for(const [x,y,X,Y] of [[172,197,179,206],[177,220,168,231],[164,236,157,255],[184,194,192,207],[137,179,131,190],[146,180,142,198],[149,264,139,272]]){line(x,y,X,Y,'brown',2);line(x-1,y-1,X-1,Y-1,'skinl');}
for(const [x,y] of [[161,144],[159,164],[169,185],[119,153],[133,157],[102,176],[91,171]]){line(x,y,x+3,y-1,'bone');px(x+2,y+3,'rust');}
// Second review: fleshy cheek volume wraps jaw hinge and narrows into muzzle.
poly([[103,174],[110,178],[111,184],[108,191],[102,198],[98,199],[101,190],[103,185]],'skin');
line(106,178,108,183,'skinl',2);line(108,185,104,192,'red',2);bolt(105,191,3);
poly([[69,176],[79,171],[88,170],[83,175],[75,179]],'brown');line(72,175,79,173,'light');
const doc=create({name:'ember_bat_static_v2',width:W,height:H,totalFrames:1,fps:8});writeFrame(doc,p);await exportFiles(doc,out+'exports');
fs.writeFileSync(out+'manifest.json',JSON.stringify({name:'ember_bat',status:'static_review_only',native_size:[320,320],ground_anchor:{x:166,y:292},facing:'lower_left',attacks:{ranged:{mouth_muzzle:{x:61,y:205},chest_muzzle:{x:129,y:220},projectile:'projectiles/ember_pellet/exports/frame-001.png'},melee:{type:'short_dive_slash',claw_contacts:[{x:119,y:298},{x:139,y:305},{x:154,y:298}]}},separated_resources:['projectiles/ember_pellet/exports/frame-001.png'],connected_parts:['Chest sacs are fixed organs: only generated ember pellet leaves the mouth/chest vent.','Wing membranes remain attached to articulated spars and shoulder sockets.','Claws, jaw and turbine remain attached to the creature.'],reference:'../../minion_individual_references_v1/ember_bat.png',authoring:'Hand-authored coordinates; no reference pixels loaded.'},null,2));
